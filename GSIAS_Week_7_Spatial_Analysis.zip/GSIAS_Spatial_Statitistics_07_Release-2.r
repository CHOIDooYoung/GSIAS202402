# 필요한 패키지 설치 및 로드 / Load required packages
# install.packages(c("dplyr", "reshape2", "plm", "spatialreg", "splm", "ggplot2", "spdep", "rnaturalearth", "sf", "WDI", "car", "FactoMineR", "ggcorrplot"))
library(dplyr)
library(reshape2)
library(plm)
library(spatialreg)
library(splm)
library(ggplot2)
library(spdep)
library(rnaturalearth)
library(sf)
library(WDI)
library(car)
library(FactoMineR)  # PCA 및 요인 분석 / Principal Component and Factor Analysis
library(ggcorrplot)  # 상관행렬 시각화 / Correlation matrix visualization
library(lmtest)

# 데이터 재현성을 위한 seed 설정 / Set seed for reproducibility
set.seed(123)

# WDI 데이터에서 추가 변수 불러오기 / Load additional variables from WDI
wdi_data <- WDI(
  country = "all", 
  indicator = c(
    "NY.GDP.MKTP.CD",      # GDP for TRO calculation
    "NE.EXP.GNFS.ZS",      # Exports as % of GDP
    "NE.IMP.GNFS.ZS",      # Imports as % of GDP
    "EG.FEC.RNEW.ZS",      # Renewable energy consumption
    "PV.EST",              # Political stability (PV)
    "GE.EST",              # Government effectiveness (GE)
    "CC.EST",              # Control of corruption (CC)
    "VA.EST"               # Voice and accountability (VA)
  ),
  start = 1960, end = 2020, extra = TRUE
)

# NA 제거 및 변수명 정리 / Remove NA and clean up variable names
wdi_data <- na.omit(wdi_data)
wdi_data$TRO <- wdi_data$NE.EXP.GNFS.ZS + wdi_data$NE.IMP.GNFS.ZS  # Trade openness calculation
colnames(wdi_data)[which(names(wdi_data) == "EG.FEC.RNEW.ZS")] <- "REC"
colnames(wdi_data)[which(names(wdi_data) == "PV.EST")] <- "PV"
colnames(wdi_data)[which(names(wdi_data) == "GE.EST")] <- "GE"
colnames(wdi_data)[which(names(wdi_data) == "CC.EST")] <- "CC"
colnames(wdi_data)[which(names(wdi_data) == "VA.EST")] <- "VA"

# 온실가스 배출량 및 GDP 데이터 불러오기 / Load GHG emissions and GDP data
ghg_data <- read.csv(file.choose(), skip = 4)   # CSV 파일 선택 / Select CSV file
ghg_data <- ghg_data %>%
  select(-Indicator.Name, -Indicator.Code) %>%
  melt(id.vars = c("Country.Name", "Country.Code"), variable.name = "Year", value.name = "GHG_Emissions") %>%
  mutate(Year = as.numeric(gsub("X", "", Year)))

gdp_data <- read.csv(file.choose(), skip = 4)
gdp_data <- gdp_data %>%
  select(-Indicator.Name, -Indicator.Code) %>%
  melt(id.vars = c("Country.Name", "Country.Code"), variable.name = "Year", value.name = "GDP_Current_USD") %>%
  mutate(Year = as.numeric(gsub("X", "", Year)))

# 데이터 병합 및 결측치 제거 / Merge data and remove missing values
merged_data <- merge(ghg_data, gdp_data, by = c("Country.Name", "Country.Code", "Year")) %>%
  filter(!is.na(GHG_Emissions) & !is.na(GDP_Current_USD))

# WDI 데이터와 병합 / Merge with WDI data for additional variables
wdi_data <- wdi_data %>%
  rename(Country.Code = iso3c, Year = year) %>%
  select(Country.Code, Year, TRO, REC, PV, GE, CC, VA)
full_data <- merge(merged_data, wdi_data, by = c("Country.Code", "Year"))

# 아프리카 국가 필터링 및 좌표 추가 / Filter for African countries and add coordinates
countries <- ne_countries(scale = "medium", returnclass = "sf")
africa_names <- countries %>% filter(continent == "Africa") %>% pull(name)
africa_data <- full_data %>% filter(Country.Name %in% africa_names)

coords <- countries %>%
  filter(continent == "Africa") %>%
  select(name, geometry) %>%
  st_centroid() %>%
  mutate(lon = st_coordinates(.)[, 1], lat = st_coordinates(.)[, 2]) %>%
  mutate(lon = lon + runif(n(), -0.001, 0.001), lat = lat + runif(n(), -0.001, 0.001))

africa_data <- africa_data %>% inner_join(coords, by = c("Country.Name" = "name"))

# 로그 변환 적용 / Apply logarithmic transformation
africa_data <- africa_data %>%
  mutate(log_GHG_Emissions = log(GHG_Emissions + 1), log_GDP_Current_USD = log(GDP_Current_USD + 1), log_REC = log(REC + 1))

# Emission trend 및 GDP에 대한 시각화 / Emission trend and GDP trend visualization
ggplot(africa_data, aes(x = Year)) +
  geom_line(aes(y = log_GHG_Emissions, color = "GHG Emissions"), size = 1) +
  geom_line(aes(y = log_GDP_Current_USD, color = "GDP (USD)"), size = 1) +
  scale_color_manual(values = c("GHG Emissions" = "red", "GDP (USD)" = "blue")) +
  labs(title = "Emission and GDP Trends over Time", x = "Year", y = "Log Scale", color = "Variable") +
  theme_minimal()

# 상관행렬 계산 및 시각화 / Compute and visualize correlation matrix
cor_matrix <- cor(africa_data %>% select(log_GHG_Emissions, log_GDP_Current_USD, log_REC, PV, GE, CC, VA), use = "complete.obs")
ggcorrplot(cor_matrix, method = "circle", type = "lower", lab = TRUE, colors = c("red", "white", "blue")) +
  labs(title = "Correlation Matrix of Key Variables", subtitle = "Using selected governance indicators and environmental data")

# PCA 및 상관서클 / PCA and correlation circle
pca_results <- PCA(africa_data %>% select(log_GHG_Emissions, log_GDP_Current_USD, log_REC, PV, GE, CC, VA), graph = FALSE)
plot(pca_results, choix = "var", title = "Correlation Circle of the 1st Factorial Plane")

# 패널 데이터 구조 설정 / Set up panel data structure
panel_data <- pdata.frame(africa_data, index = c("Country.Code", "Year"))

# 공간 가중치 행렬 생성 및 자기상관 검정 / Create spatial weights matrix and autocorrelation test
africa_data$lon <- as.numeric(africa_data$lon)
africa_data$lat <- as.numeric(africa_data$lat)
coords_matrix <- as.matrix(africa_data[, c("lon", "lat")])
dist_neighbors <- dnearneigh(coords_matrix, d1 = 0, d2 = 50)
neighbors <- nb2listw(dist_neighbors, style = "W")  

# Moran's I 자기상관 검정 / Moran's I for spatial autocorrelation
moran_test <- moran.test(africa_data$log_GHG_Emissions, listw = neighbors)
print("Moran's I test for spatial autocorrelation:")
print(moran_test)

# 공간 모델 분석 (SLM, SEM, SDM) / Spatial model analysis (SLM, SEM, SDM)
slm_model <- lagsarlm(log_GHG_Emissions ~ log_GDP_Current_USD + log_REC + PV + GE + CC + VA, data = africa_data, listw = neighbors)
print("Spatial Lag Model (SLM) Summary:")
summary(slm_model)

sem_model <- errorsarlm(log_GHG_Emissions ~ log_GDP_Current_USD + log_REC + PV + GE + CC + VA, data = africa_data, listw = neighbors)
print("Spatial Error Model (SEM) Summary:")
summary(sem_model)

sdm_model <- lagsarlm(log_GHG_Emissions ~ log_GDP_Current_USD + log_REC + PV + GE + CC + VA + lag(log_GDP_Current_USD) + lag(log_REC), data = africa_data, listw = neighbors)
print("Spatial Durbin Model (SDM) Summary:")
summary(sdm_model)

# 잔차의 Moran's I 검정 / Moran's I for residuals
slm_residuals <- residuals(slm_model)
moran_residuals_test <- moran.test(slm_residuals, listw = neighbors)
print("Moran's I test for residuals of SLM model:")
print(moran_residuals_test)

# 정적 패널 모델 분석 / Static Panel Model Analysis
fe_panel_model <- plm(log_GHG_Emissions ~ log_GDP_Current_USD + log_REC + PV + GE + CC + VA, data = panel_data, model = "within")
print("Fixed Effects Panel Model Summary:")
summary(fe_panel_model)

re_panel_model <- plm(log_GHG_Emissions ~ log_GDP_Current_USD + log_REC + PV + GE + CC + VA, data = panel_data, model = "random")
print("Random Effects Panel Model Summary:")
summary(re_panel_model)

# 시차 포함 고정 효과 패널 모델 (간소화된 동적 패널 모델) / Fixed Effects Panel Model with Lagged Variables
fe_lag_model <- plm(log_GHG_Emissions ~ lag(log_GHG_Emissions, 1) + log_GDP_Current_USD + log_REC + PV + GE + CC + VA, data = panel_data, model = "within")
print("Fixed Effects Model with Lagged Dependent Variable Summary:")
summary(fe_lag_model)

# --- Spatial Static Panel Model with Maximum Observations --- #

# Obtain unique coordinates for each country in the filtered balanced panel data
unique_coords_balanced <- africa_data %>%
  filter(Country.Code %in% countries_to_include) %>%
  select(Country.Code, lon, lat) %>%
  distinct(Country.Code, .keep_all = TRUE)

# Re-create the spatial weights matrix using only countries in the balanced panel
coords_matrix_balanced <- as.matrix(unique_coords_balanced[, c("lon", "lat")])
dist_neighbors_balanced <- dnearneigh(coords_matrix_balanced, d1 = 0, d2 = 50)
unique_neighbors_balanced <- nb2listw(dist_neighbors_balanced, style = "W")

# Verify the number of spatial units matches the countries in panel_data_balanced
print(length(unique_neighbors_balanced$neighbours))
print(n_distinct(panel_data_balanced$Country.Code))

# Construct the spatial static panel model with the balanced dataset
spatial_static_panel_model_balanced <- spml(
  log_GHG_Emissions ~ log_GDP_Current_USD + log_REC + PV + GE + CC + VA,
  data = panel_data_balanced,
  listw = unique_neighbors_balanced, # Use spatial weights for matched countries
  model = "random",                  # Random effects for balanced panel
  lag = TRUE,                        # Spatial lag model (SAR)
  spatial.error = "b"                # Both spatial and idiosyncratic error terms
)

# Output the model summary
print("Spatial Static Panel Model Summary with Balanced Panel Data:")
summary(spatial_static_panel_model_balanced)


# --- Spatial Dynamic Panel Model --- #

# Creating a spatial dynamic panel model with GMM estimation
# Uses the pgmm function for dynamic modeling
spatial_dynamic_panel_model <- pgmm(
  log_GHG_Emissions ~ lag(log_GHG_Emissions, 1) + log_GDP_Current_USD + log_REC + PV + GE + CC + VA |
    lag(log_GHG_Emissions, 2:3),  # Instruments with lagged dependent variables
  data = panel_data,
  effect = "individual",
  model = "twosteps",
  transformation = "ld",  # First-difference transformation
  listw = neighbors       # Spatial weights for the spatial lag
)

print("Spatial Dynamic Panel Model Summary:")
summary(spatial_dynamic_panel_model)


# 해우스만 검정 (고정효과 vs. 랜덤효과 선택) / Hausman Test for Model Selection
hausman_test <- phtest(fe_panel_model, re_panel_model)
print("Hausman Test Result:")
print(hausman_test)

# 패널 데이터 잔차의 이분산성 검정 / Breusch-Pagan Test for Heteroskedasticity in Panel Data
bp_test_fe <- bptest(fe_panel_model)
bp_test_re <- bptest(re_panel_model)
print("Breusch-Pagan Test for Fixed Effects Model:")
print(bp_test_fe)
print("Breusch-Pagan Test for Random Effects Model:")
print(bp_test_re)

# 잔차의 자동상관성 검정 / Test for Serial Correlation in Residuals (Durbin-Watson Test)
dw_test_fe <- pdwtest(fe_panel_model, alternative = "two.sided")
dw_test_re <- pdwtest(re_panel_model, alternative = "two.sided")
print("Durbin-Watson Test for Fixed Effects Model:")
print(dw_test_fe)
print("Durbin-Watson Test for Random Effects Model:")
print(dw_test_re)

# 시각화: SLM, SEM, SDM 모델의 GDP 계수 비교 / Visualization of GDP coefficients across SLM, SEM, SDM
model_results <- data.frame(
  Model = c("SLM", "SEM", "SDM"),
  Coefficient = c(coef(slm_model)["log_GDP_Current_USD"],
                  coef(sem_model)["log_GDP_Current_USD"],
                  coef(sdm_model)["log_GDP_Current_USD"])
)

ggplot(model_results, aes(x = Model, y = Coefficient)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  theme_minimal() +
  labs(title = "Comparison of GDP Coefficients across Spatial Models (SLM, SEM, SDM)",
       x = "Model",
       y = "Estimated Coefficient for log(GDP USD)")

print("This visualization shows the impact of GDP on greenhouse gas emissions across different spatial models (SLM, SEM, SDM).")

# 주성분 분석 및 상관행렬 결과 출력 / Summary of PCA and correlation diagnostics
print("PCA Correlation Matrix in Chosen Components:")
pca_corr_matrix <- cor(pca_results$ind$coord)
print(pca_corr_matrix)

# 최종적으로 모든 검증 및 모델 요약을 확인하여 분석 결과 해석 / Final interpretation after all diagnostics and summaries
print("Complete model analysis and diagnostics completed.")

# 추가 검증: 분산 팽창 계수(VIF)로 다중공선성 확인 / Additional Verification: VIF for Multicollinearity
vif_results <- vif(lm(log_GHG_Emissions ~ log_GDP_Current_USD + log_REC + PV + GE + CC + VA, data = africa_data))
print("VIF Results for Multicollinearity Check:")
print(vif_results)
