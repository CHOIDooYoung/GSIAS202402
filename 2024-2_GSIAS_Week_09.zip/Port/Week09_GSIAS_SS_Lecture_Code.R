# 필요한 패키지 로드 / Load necessary packages
library(readr)
library(readxl)
library(dplyr)
library(tidyr)
library(sf)
library(spdep)
library(ggplot2)
library(rnaturalearth)
library(rnaturalearthdata)

# 세계 국가 경계 데이터 로드 / Load world boundary data
world <- ne_countries(scale = "medium", returnclass = "sf")

# 데이터 로드 / Load data
Shiping_volum_data <- read_excel(file.choose())  # API_IS.SHP.GOOD.TU_DS2_en_csv_v2_23509
smdg_data <- read_csv(file.choose())  # SMDG Terminal Code List

# WDI 데이터 로드
food_production_data <- read_csv(file.choose()) # API_AG.PRD.FOOD.XD_DS2_en_csv_v2_10483.csv
undernourishment_data <- read_csv(file.choose()) # API_SN.ITK.DEFC.ZS_DS2_en_csv_v2_10009.csv
trade_percent_data <- read_csv(file.choose()) # API_NE.TRD.GNFS.ZS_DS2_en_csv_v2_9994.csv

# WDI 데이터 전처리: 연도 데이터를 열에서 행으로 변환 / WDI data preprocessing: Transform year data from columns to rows
food_production_data_long <- food_production_data %>%
  pivot_longer(cols = -c(1, 2), names_to = "Year", values_to = "Food_Production_Index") %>%
  na.omit()

undernourishment_data_long <- undernourishment_data %>%
  pivot_longer(cols = -c(1, 2), names_to = "Year", values_to = "Prevalence_of_Undernourishment") %>%
  na.omit()

trade_percent_data_long <- trade_percent_data %>%
  pivot_longer(cols = -c(1, 2), names_to = "Year", values_to = "Trade_as_Percent_of_GDP") %>%
  na.omit()

# 연도 데이터를 열에서 행으로 변환하여 패널 데이터 구조로 변경 / Transform year data to panel data structure
Shiping_volum_data_long <- Shiping_volum_data %>%
  pivot_longer(cols = -c(1, 2), names_to = "Year", values_to = "Shiping_Volum")

# 터미널 데이터를 sf 객체로 변환 / Convert terminal data to sf object
smdg_sf <- smdg_data %>%
  filter(!is.na(Latitude) & !is.na(Longitude)) %>%
  st_as_sf(coords = c("Longitude", "Latitude"), crs = 4326)

# 터미널 데이터를 국가 경계와 조인하여 국가 정보 추가 / Join terminal data with country boundaries
smdg_with_country <- st_join(smdg_sf, world, join = st_within)

# 항구 수를 국가별로 계산 / Count the number of ports per country
ports_per_country <- smdg_with_country %>%
  group_by(sov_a3) %>%
  summarize(Ports = n())

# 항구 수 데이터를 Shiping_volum_data_long와 결합 / Add Ports data to the panel data
combined_data <- Shiping_volum_data_long %>%
  left_join(ports_per_country, by = c("Country Code" = "sov_a3")) %>%  # Join Ports data
  left_join(food_production_data_long, by = c("Country Code", "Year")) %>%
  left_join(undernourishment_data_long, by = c("Country Code", "Year")) %>%
  left_join(trade_percent_data_long, by = c("Country Code", "Year")) %>%
  filter(
    !is.na(Shiping_Volum) & 
      !is.na(Food_Production_Index) & 
      !is.na(Prevalence_of_Undernourishment) & 
      !is.na(Trade_as_Percent_of_GDP) & 
      !is.na(Ports)  # Ensure there are no missing values for Ports
  )

# 결합된 데이터를 확인 / Check the combined data
head(combined_data)


#==============================================================
# 2020년 데이터만 필터링 / Filter data for the year 2020
#==============================================================
combined_data_2020 <- combined_data %>%
  filter(Year == "2020") %>%
  na.omit()

# 로그 변환 및 DV 생성 / Log transform and create DV
combined_data_2020 <- combined_data_2020 %>%
  mutate(
    Log_Ports = log(Ports + 1),  # Log transform (add 1 to avoid 0)
    Log_Trade_Volume = log(Shiping_Volum + 1),  # Log transform (add 1 to avoid 0)
    DV = Log_Ports + Log_Trade_Volume  # Create DV by adding log-transformed values
  )


# 상관 분석을 위한 변수 선택 / Select variables for correlation analysis
correlation_data <- combined_data_2020 %>%
  select(DV, Food_Production_Index, Prevalence_of_Undernourishment, Trade_as_Percent_of_GDP)

# 상관 행렬 계산 / Compute the correlation matrix
correlation_matrix <- cor(correlation_data, use = "complete.obs", method = "pearson")

# 상관 행렬 출력 / Print the correlation matrix
print(correlation_matrix)


# 다중 회귀 분석 / Multiple regression analysis for 2020 data
model_2020 <- lm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020
)
summary(model_2020)


# 지도 시각화 / Map visualization
ggplot() +
  geom_sf(data = world, fill = "lightgrey", color = "black", size = 0.2) +  # Plot country boundaries
  geom_sf(data = ports_per_country, aes(size = Ports, geometry = geometry), color = "blue", alpha = 0.6) +  # Plot port sizes
  theme_minimal() +
  labs(
    title = "Terminal Locations and Number of Ports",
    size = "Number of Ports"
  )


#=============================
# Moran i
#=============================

# 필터링된 데이터에서 공간 객체 생성 / Create spatial object from filtered data
combined_data_2020_sf <- combined_data_2020 %>%
  left_join(world, by = c("Country Code" = "iso_a3")) %>%
  st_as_sf()

# 공간적 가중치 행렬 생성 (인접 행렬) / Create spatial weights matrix (neighbor matrix)
coords <- st_centroid(st_geometry(combined_data_2020_sf)) %>% st_coordinates()
neighbors <- knearneigh(coords, k = 5)  # k-최근접 이웃 사용 / Use k-nearest neighbors
listw <- nb2listw(knn2nb(neighbors), style = "W", zero.policy = TRUE)

# Moran's I 검정 / Moran's I test
moran_test <- moran.test(combined_data_2020$DV, listw, zero.policy = TRUE)
print(moran_test)



# 필요한 패키지 로드 / Load necessary packages
library(spatialreg)  # 공간 회귀 분석을 위한 패키지

# Spatial Lag Model (SLM) 구축 / Construct the Spatial Lag Model
lag_model <- lagsarlm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020_sf, 
  listw = listw, 
  zero.policy = TRUE
)
summary(lag_model)  # SLM 결과 요약 / Summary of the SLM

# Spatial Error Model (SEM) 구축 / Construct the Spatial Error Model
error_model <- errorsarlm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020_sf, 
  listw = listw, 
  zero.policy = TRUE
)
summary(error_model)  # SEM 결과 요약 / Summary of the SEM


#=======================
# Middle East & Africa Expansion
#=======================

# 중동 및 아프리카 국가의 국가 코드 목록 / List of Middle Eastern and African country codes
middle_east_africa_countries <- c(
  "SAU", "ARE", "QAT", "KWT", "OMN", "BHR", "IRQ", "JOR", "LBN", "SYR", "YEM", "IRN", "ISR", "EGY", "TUR", 
  "DZA", "AGO", "BEN", "BWA", "BFA", "BDI", "CMR", "CPV", "CAF", "TCD", 
  "COM", "COG", "CIV", "DJI", "EGY", "GNQ", "ERI", "ETH", "GAB", "GMB", 
  "GHA", "GIN", "GNB", "KEN", "LSO", "LBR", "LBY", "MDG", "MWI", "MLI", 
  "MRT", "MUS", "MAR", "MOZ", "NAM", "NER", "NGA", "RWA", "STP", "SEN", 
  "SYC", "SLE", "SOM", "ZAF", "SSD", "SDN", "SWZ", "TGO", "TUN", "UGA", 
  "TZA", "ZMB", "ZWE"
)

# 중동 및 아프리카 국가 데이터 필터링 / Filter the data for Middle Eastern and African countries
combined_data_2020_mea <- combined_data_2020 %>%
  filter(`Country Code` %in% middle_east_africa_countries) %>%
  na.omit()

# 상관 분석을 위한 변수 선택 / Select variables for correlation analysis
correlation_data_mea <- combined_data_2020_mea %>%
  select(DV, Food_Production_Index, Prevalence_of_Undernourishment, Trade_as_Percent_of_GDP)

# 상관 행렬 계산 / Compute the correlation matrix for Middle Eastern and African countries
correlation_matrix_mea <- cor(correlation_data_mea, use = "complete.obs", method = "pearson")

# 상관 행렬 출력 / Print the correlation matrix
print(correlation_matrix_mea)

# 다중 회귀 분석 / Multiple regression analysis for Middle Eastern and African data
model_2020_mea <- lm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020_mea
)
summary(model_2020_mea)

# 지도 시각화 (중동 및 아프리카 지역) / Map visualization (Middle Eastern and African region)
ggplot() +
  geom_sf(data = world, fill = "lightgrey", color = "black", size = 0.2) +  # Plot country boundaries
  geom_sf(data = ports_per_country %>% filter(sov_a3 %in% middle_east_africa_countries), 
          aes(size = Ports, geometry = geometry), color = "blue", alpha = 0.6) +  # Plot port sizes
  theme_minimal() +
  labs(
    title = "Terminal Locations and Number of Ports in the Middle East & Africa",
    size = "Number of Ports"
  )

#=============================
# Moran I (중동 및 아프리카) / Moran's I for Middle Eastern and African countries
#=============================

# 필터링된 데이터에서 공간 객체 생성 / Create spatial object from filtered data
combined_data_2020_mea_sf <- combined_data_2020_mea %>%
  left_join(world, by = c("Country Code" = "iso_a3")) %>%
  st_as_sf()

# 공간적 가중치 행렬 생성 / Create spatial weights matrix
coords_mea <- st_centroid(st_geometry(combined_data_2020_mea_sf)) %>% st_coordinates()
neighbors_mea <- knearneigh(coords_mea, k = 5)  # k-최근접 이웃 사용 / Use k-nearest neighbors
listw_mea <- nb2listw(knn2nb(neighbors_mea), style = "W", zero.policy = TRUE)

# Moran's I 검정 / Moran's I test
moran_test_mea <- moran.test(combined_data_2020_mea$DV, listw_mea, zero.policy = TRUE)
print(moran_test_mea)

# Spatial Lag Model (SLM) for Middle Eastern and African countries
lag_model_mea <- lagsarlm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020_mea_sf, 
  listw = listw_mea, 
  zero.policy = TRUE
)
summary(lag_model_mea)

# Spatial Error Model (SEM) for Middle Eastern and African countries
error_model_mea <- errorsarlm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020_mea_sf, 
  listw = listw_mea, 
  zero.policy = TRUE
)
summary(error_model_mea)



#=======================
#Middle East
#=======================


# 중동 국가의 국가 코드 목록 / List of Middle Eastern country codes
middle_east_countries <- c("SAU", "ARE", "QAT", "KWT", "OMN", "BHR", "IRQ", "JOR", "LBN", "SYR", "YEM", "IRN", "ISR", "EGY", "TUR")

# 중동 국가 데이터 필터링 / Filter the data for Middle Eastern countries
combined_data_2020_me <- combined_data_2020 %>%
  filter(`Country Code` %in% middle_east_countries) %>%
  na.omit()

# 상관 분석을 위한 변수 선택 / Select variables for correlation analysis
correlation_data_me <- combined_data_2020_me %>%
  select(DV, Food_Production_Index, Prevalence_of_Undernourishment, Trade_as_Percent_of_GDP)

# 상관 행렬 계산 / Compute the correlation matrix for Middle Eastern countries
correlation_matrix_me <- cor(correlation_data_me, use = "complete.obs", method = "pearson")

# 상관 행렬 출력 / Print the correlation matrix
print(correlation_matrix_me)

# 다중 회귀 분석 / Multiple regression analysis for Middle Eastern data
model_2020_me <- lm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020_me
)
summary(model_2020_me)

# 지도 시각화 (중동 지역만) / Map visualization (Middle Eastern region only)
ggplot() +
  geom_sf(data = world, fill = "lightgrey", color = "black", size = 0.2) +  # Plot country boundaries
  geom_sf(data = ports_per_country %>% filter(sov_a3 %in% middle_east_countries), 
          aes(size = Ports, geometry = geometry), color = "blue", alpha = 0.6) +  # Plot port sizes
  theme_minimal() +
  labs(
    title = "Terminal Locations and Number of Ports in the Middle East",
    size = "Number of Ports"
  )

#=============================
# Moran I (중동 국가) / Moran's I for Middle Eastern countries
#=============================

# 필터링된 데이터에서 공간 객체 생성 (중동 국가) / Create spatial object from filtered data (Middle East)
combined_data_2020_me_sf <- combined_data_2020_me %>%
  left_join(world, by = c("Country Code" = "iso_a3")) %>%
  st_as_sf()

# 공간적 가중치 행렬 생성 (중동 국가) / Create spatial weights matrix for Middle East
coords_me <- st_centroid(st_geometry(combined_data_2020_me_sf)) %>% st_coordinates()
neighbors_me <- knearneigh(coords_me, k = 2)  # k-최근접 이웃 사용 / Use k-nearest neighbors
listw_me <- nb2listw(knn2nb(neighbors_me), style = "W", zero.policy = TRUE)

# Moran's I 검정 (중동 국가) / Moran's I test for Middle Eastern countries
moran_test_me <- moran.test(combined_data_2020_me$DV, listw_me, zero.policy = TRUE)
print(moran_test_me)

# Spatial Lag Model (SLM) for Middle Eastern countries
lag_model_me <- lagsarlm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020_me_sf, 
  listw = listw_me, 
  zero.policy = TRUE
)
summary(lag_model_me)

# Spatial Error Model (SEM) for Middle Eastern countries
error_model_me <- errorsarlm(
  DV ~ Food_Production_Index + Prevalence_of_Undernourishment + Trade_as_Percent_of_GDP, 
  data = combined_data_2020_me_sf, 
  listw = listw_me, 
  zero.policy = TRUE
)
summary(error_model_me)

